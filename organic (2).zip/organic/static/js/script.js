console.log("Organic Spices website loaded");
